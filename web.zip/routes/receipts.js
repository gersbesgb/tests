const express = require("express");
const db = require("../db");
const { authRequired, adminRequired } = require("../middleware/auth");

const router = express.Router();
router.use(authRequired);

router.get("/mine", (req, res) => {
  const rows = db.prepare(
    `SELECT r.id, r.item, r.amount, r.note, r.created_at, lk.key AS key
     FROM receipts r LEFT JOIN license_keys lk ON lk.id = r.key_id
     WHERE r.user_id = ? ORDER BY r.id DESC`
  ).all(req.user.id);
  res.json({ receipts: rows });
});

// ── admin only ──
router.get("/", adminRequired, (req, res) => {
  const rows = db.prepare(
    `SELECT r.id, r.item, r.amount, r.note, r.created_at, u.username AS owner, lk.key AS key
     FROM receipts r LEFT JOIN users u ON u.id = r.user_id LEFT JOIN license_keys lk ON lk.id = r.key_id
     ORDER BY r.id DESC`
  ).all();
  res.json({ receipts: rows });
});

router.post("/", adminRequired, (req, res) => {
  const { username, item, amount, note, keyId } = req.body || {};
  if (!username || !item || !amount) return res.status(400).json({ error: "Username, item and amount are required." });
  const u = db.prepare("SELECT id FROM users WHERE username_ci = ?").get(String(username).toLowerCase());
  if (!u) return res.status(404).json({ error: `No user named "${username}".` });
  const info = db.prepare(
    "INSERT INTO receipts (user_id, key_id, item, amount, note) VALUES (?, ?, ?, ?, ?)"
  ).run(u.id, keyId || null, item, amount, note || null);
  res.json({ id: info.lastInsertRowid });
});

module.exports = router;
