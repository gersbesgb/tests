// ── theme switcher (front-end only, matches the desktop app's palettes) ──
const THEMES = ["indium","ocean","prestige","violet","amber","cyan","mono"];
const themebar = document.getElementById("themebar");
THEMES.forEach(t => {
  const d = document.createElement("div");
  d.className = "dot"; d.dataset.theme = t;
  d.style.background = getComputedStyle(document.documentElement).getPropertyValue("--accent"); // temp, fixed below
  d.title = t;
  d.onclick = () => setTheme(t);
  themebar.appendChild(d);
});
function setTheme(t) {
  document.documentElement.setAttribute("data-theme", t === "indium" ? "" : t);
  localStorage.setItem("indium_theme", t);
  [...themebar.children].forEach(el => el.classList.toggle("active", el.dataset.theme === t));
}
setTheme(localStorage.getItem("indium_theme") || "indium");
// color the dots to their own theme accent, not the current one
const DOT_COLORS = { indium:"#7ce854", ocean:"#48a8ff", prestige:"#ff4896", violet:"#ac70ff", amber:"#ffb840", cyan:"#30e8de", mono:"#e2e4ec" };
[...themebar.children].forEach(el => el.style.background = DOT_COLORS[el.dataset.theme]);

// ── API helper ──
// When this site is hosted on Cloudflare Pages and the backend on Render
// (or anywhere else), they're different domains — point this at your
// Render URL. Leave it "" only if the site and API are served from the
// same place (e.g. testing locally with `npm start`).
const API = "https://REPLACE-WITH-YOUR-RENDER-URL.onrender.com";
let TOKEN = localStorage.getItem("indium_token") || null;
let ME = null;

async function api(path, opts = {}) {
  const headers = { "Content-Type": "application/json", ...(opts.headers || {}) };
  if (TOKEN) headers.Authorization = "Bearer " + TOKEN;
  const res = await fetch(API + path, { ...opts, headers });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || "Something went wrong.");
  return data;
}

function downloadExe() { window.location.href = API + "/download"; }

// ── view switching ──
function show(id) {
  ["landing", "auth", "dash"].forEach(v => document.getElementById("view-" + v).classList.toggle("hidden", v !== id));
}

document.getElementById("nav-login").onclick = () => { setAuthTab("login"); show("auth"); };
document.getElementById("nav-signup").onclick = () => { setAuthTab("register"); show("auth"); };
document.getElementById("cta-signup").onclick = () => { setAuthTab("register"); show("auth"); };
document.getElementById("nav-dash").onclick = () => { show("dash"); loadDashboard(); };
document.getElementById("nav-logout").onclick = () => { TOKEN = null; ME = null; localStorage.removeItem("indium_token"); refreshNav(); show("landing"); };

let authMode = "login";
function setAuthTab(mode) {
  authMode = mode;
  document.querySelectorAll("[data-authtab]").forEach(t => t.classList.toggle("active", t.dataset.authtab === mode));
  document.getElementById("auth-submit").textContent = mode === "login" ? "Log in" : "Create account";
  document.getElementById("auth-msg").className = "msg";
}
document.querySelectorAll("[data-authtab]").forEach(t => t.onclick = () => setAuthTab(t.dataset.authtab));

document.getElementById("auth-submit").onclick = async () => {
  const username = document.getElementById("auth-username").value.trim();
  const password = document.getElementById("auth-password").value;
  const msg = document.getElementById("auth-msg");
  try {
    const data = await api("/api/auth/" + (authMode === "login" ? "login" : "register"), {
      method: "POST", body: JSON.stringify({ username, password }),
    });
    TOKEN = data.token; ME = data.user; localStorage.setItem("indium_token", TOKEN);
    refreshNav(); show("dash"); loadDashboard();
  } catch (e) { msg.textContent = e.message; msg.className = "msg err"; }
};

function refreshNav() {
  document.getElementById("nav-login").classList.toggle("hidden", !!TOKEN);
  document.getElementById("nav-signup").classList.toggle("hidden", !!TOKEN);
  document.getElementById("nav-dash").classList.toggle("hidden", !TOKEN);
  document.getElementById("nav-logout").classList.toggle("hidden", !TOKEN);
}

// ── dashboard tabs ──
document.querySelectorAll(".tab[data-tab]").forEach(t => t.onclick = () => {
  document.querySelectorAll(".tab[data-tab]").forEach(x => x.classList.toggle("active", x === t));
  ["overview", "keys", "receipts", "admin"].forEach(p => document.getElementById("pane-" + p).classList.toggle("hidden", p !== t.dataset.tab));
});

async function loadDashboard() {
  try {
    const me = await api("/api/auth/me"); ME = me.user;
    document.getElementById("ov-username").textContent = ME.username + (ME.role === "admin" ? " (admin)" : "");
    document.getElementById("tab-admin").classList.toggle("hidden", ME.role !== "admin");
  } catch (e) { TOKEN = null; localStorage.removeItem("indium_token"); refreshNav(); show("landing"); return; }

  const mine = await api("/api/keys/mine");
  document.getElementById("ov-keys").textContent = mine.keys.filter(k => k.status === "active").length + " active";
  document.getElementById("keys-table").innerHTML = mine.keys.map(k => `
    <tr><td class="key-mono">${k.key}</td>
        <td><span class="chip ${k.status === "active" ? "ok" : "bad"}">${k.status}</span></td>
        <td>${k.expires_at || "Lifetime"}</td><td>${fmtDate(k.created_at)}</td></tr>`).join("") ||
    `<tr><td colspan="4" style="color:var(--dim)">No keys yet — redeem one above.</td></tr>`;

  const rec = await api("/api/receipts/mine");
  document.getElementById("receipts-table").innerHTML = rec.receipts.map(r => `
    <tr><td>${r.item}</td><td>${r.amount}</td><td class="key-mono">${r.key || "—"}</td><td>${fmtDate(r.created_at)}</td></tr>`).join("") ||
    `<tr><td colspan="4" style="color:var(--dim)">No receipts yet.</td></tr>`;

  if (ME.role === "admin") loadAdmin();
}

function fmtDate(s) { return s ? s.split(" ")[0] : "—"; }

async function redeemKey() {
  const msg = document.getElementById("redeem-msg"); const key = document.getElementById("redeem-input").value.trim();
  try { await api("/api/keys/redeem", { method: "POST", body: JSON.stringify({ key }) });
    msg.textContent = "Key redeemed!"; msg.className = "msg ok"; loadDashboard();
  } catch (e) { msg.textContent = e.message; msg.className = "msg err"; }
}

async function genKey() {
  const msg = document.getElementById("gen-msg");
  const username = document.getElementById("gen-username").value.trim() || undefined;
  const note = document.getElementById("gen-note").value.trim() || undefined;
  const expiresAt = document.getElementById("gen-expires").value.trim() || undefined;
  try {
    const data = await api("/api/keys/generate", { method: "POST", body: JSON.stringify({ username, note, expiresAt }) });
    msg.textContent = "Generated: " + data.key; msg.className = "msg ok"; loadAdmin();
  } catch (e) { msg.textContent = e.message; msg.className = "msg err"; }
}

async function addReceipt() {
  const msg = document.getElementById("rec-msg");
  const username = document.getElementById("rec-username").value.trim();
  const item = document.getElementById("rec-item").value.trim();
  const amount = document.getElementById("rec-amount").value.trim();
  try { await api("/api/receipts", { method: "POST", body: JSON.stringify({ username, item, amount }) });
    msg.textContent = "Receipt added."; msg.className = "msg ok"; loadAdmin();
  } catch (e) { msg.textContent = e.message; msg.className = "msg err"; }
}

async function loadAdmin() {
  const keys = await api("/api/keys");
  document.getElementById("admin-keys-table").innerHTML = keys.keys.map(k => `
    <tr><td class="key-mono">${k.key}</td><td>${k.owner || "—"}</td>
        <td><span class="chip ${k.status === "active" ? "ok" : "bad"}">${k.status}</span></td>
        <td>${k.note || "—"}</td>
        <td>${k.status === "active" ? `<button class="btn danger" onclick="revokeKey(${k.id})">Revoke</button>` : ""}</td></tr>`).join("");

  const rec = await api("/api/receipts");
  document.getElementById("admin-receipts-table").innerHTML = rec.receipts.map(r => `
    <tr><td>${r.owner || "—"}</td><td>${r.item}</td><td>${r.amount}</td><td>${fmtDate(r.created_at)}</td></tr>`).join("");
}

async function revokeKey(id) { await api(`/api/keys/${id}/revoke`, { method: "POST" }); loadAdmin(); }

// ── boot ──
refreshNav();
if (TOKEN) { show("dash"); loadDashboard(); } else { show("landing"); }
