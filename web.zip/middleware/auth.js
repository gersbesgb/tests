const jwt = require("jsonwebtoken");
const db = require("../db");

function authRequired(req, res, next) {
  const header = req.headers.authorization || "";
  const token = header.startsWith("Bearer ") ? header.slice(7) : null;
  if (!token) return res.status(401).json({ error: "Not logged in." });
  try {
    const payload = jwt.verify(token, process.env.JWT_SECRET);
    const user = db.prepare("SELECT id, username, role FROM users WHERE id = ?").get(payload.uid);
    if (!user) return res.status(401).json({ error: "Session no longer valid." });
    req.user = user;
    next();
  } catch (e) {
    return res.status(401).json({ error: "Session expired, please log in again." });
  }
}

// Real server-side role check — not just a hidden button in the UI.
function adminRequired(req, res, next) {
  if (!req.user || req.user.role !== "admin") {
    return res.status(403).json({ error: "Admin access required." });
  }
  next();
}

module.exports = { authRequired, adminRequired };
