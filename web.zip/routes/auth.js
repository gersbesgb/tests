const express = require("express");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const db = require("../db");
const { authRequired } = require("../middleware/auth");

const router = express.Router();

const USERNAME_RE = /^[a-zA-Z0-9_]{3,20}$/;

function sign(user) {
  return jwt.sign({ uid: user.id }, process.env.JWT_SECRET, { expiresIn: "30d" });
}

function publicUser(u) {
  return { id: u.id, username: u.username, role: u.role };
}

router.post("/register", (req, res) => {
  const { username, password } = req.body || {};
  if (!username || !password) return res.status(400).json({ error: "Username and password are required." });
  if (!USERNAME_RE.test(username)) return res.status(400).json({ error: "Username must be 3-20 letters, numbers or underscores." });
  if (String(password).length < 8) return res.status(400).json({ error: "Password must be at least 8 characters." });

  const ci = username.toLowerCase();
  const exists = db.prepare("SELECT id FROM users WHERE username_ci = ?").get(ci);
  if (exists) return res.status(409).json({ error: "That username is already taken." });

  // The admin username (set in .env as ADMIN_USERNAME) gets admin access the
  // first — and only the first — time it registers. After that the name is
  // taken like any other, so it can't be re-claimed by someone else.
  const adminName = (process.env.ADMIN_USERNAME || "").toLowerCase();
  const role = adminName && ci === adminName ? "admin" : "user";

  const hash = bcrypt.hashSync(password, 12);
  const info = db.prepare(
    "INSERT INTO users (username, username_ci, password_hash, role) VALUES (?, ?, ?, ?)"
  ).run(username, ci, hash, role);

  const user = db.prepare("SELECT id, username, role FROM users WHERE id = ?").get(info.lastInsertRowid);
  res.json({ token: sign(user), user: publicUser(user) });
});

router.post("/login", (req, res) => {
  const { username, password } = req.body || {};
  if (!username || !password) return res.status(400).json({ error: "Username and password are required." });
  const user = db.prepare("SELECT * FROM users WHERE username_ci = ?").get(String(username).toLowerCase());
  if (!user || !bcrypt.compareSync(password, user.password_hash)) {
    return res.status(401).json({ error: "Incorrect username or password." });
  }
  res.json({ token: sign(user), user: publicUser(user) });
});

router.get("/me", authRequired, (req, res) => {
  res.json({ user: publicUser(req.user) });
});

module.exports = router;
