const express = require("express");
const crypto = require("crypto");
const db = require("../db");
const { authRequired, adminRequired } = require("../middleware/auth");

const router = express.Router();

function makeKey() {
  const group = () => crypto.randomBytes(2).toString("hex").toUpperCase();
  return `INDM-${group()}-${group()}-${group()}`;
}

// Public — this is the endpoint the .exe itself calls. No login required,
// since the desktop app only has a key, not a username/password.
router.post("/validate", (req, res) => {
  const { key } = req.body || {};
  if (!key) return res.status(400).json({ valid: false, error: "No key provided." });
  const row = db.prepare(
    `SELECT lk.*, u.username AS owner_username
     FROM license_keys lk LEFT JOIN users u ON u.id = lk.user_id
     WHERE lk.key = ?`
  ).get(String(key).trim());

  if (!row) return res.json({ valid: false, error: "Unknown key." });
  if (row.status !== "active") return res.json({ valid: false, error: "This key was revoked." });
  if (row.expires_at && new Date(row.expires_at) < new Date()) return res.json({ valid: false, error: "This key expired." });

  if (!row.activated_at) db.prepare("UPDATE license_keys SET activated_at = datetime('now') WHERE id = ?").run(row.id);
  res.json({ valid: true, expires: row.expires_at || null, username: row.owner_username || null });
});

// Everything below requires login.
router.use(authRequired);

router.get("/mine", (req, res) => {
  const rows = db.prepare(
    "SELECT id, key, note, status, expires_at, created_at, activated_at FROM license_keys WHERE user_id = ? ORDER BY id DESC"
  ).all(req.user.id);
  res.json({ keys: rows });
});

// Redeem an unassigned key (e.g. one an admin generated ahead of a sale)
// onto your own account.
router.post("/redeem", (req, res) => {
  const { key } = req.body || {};
  if (!key) return res.status(400).json({ error: "No key provided." });
  const row = db.prepare("SELECT * FROM license_keys WHERE key = ?").get(String(key).trim());
  if (!row) return res.status(404).json({ error: "Unknown key." });
  if (row.user_id) return res.status(409).json({ error: "That key already belongs to an account." });
  db.prepare("UPDATE license_keys SET user_id = ? WHERE id = ?").run(req.user.id, row.id);
  res.json({ ok: true });
});

// ── admin only ──
router.get("/", adminRequired, (req, res) => {
  const rows = db.prepare(
    `SELECT lk.id, lk.key, lk.note, lk.status, lk.expires_at, lk.created_at, lk.activated_at, u.username AS owner
     FROM license_keys lk LEFT JOIN users u ON u.id = lk.user_id ORDER BY lk.id DESC`
  ).all();
  res.json({ keys: rows });
});

router.post("/generate", adminRequired, (req, res) => {
  const { username, note, expiresAt } = req.body || {};
  let userId = null;
  if (username) {
    const u = db.prepare("SELECT id FROM users WHERE username_ci = ?").get(String(username).toLowerCase());
    if (!u) return res.status(404).json({ error: `No user named "${username}". Leave blank to create an unassigned key.` });
    userId = u.id;
  }
  const key = makeKey();
  const info = db.prepare(
    "INSERT INTO license_keys (key, user_id, note, expires_at) VALUES (?, ?, ?, ?)"
  ).run(key, userId, note || null, expiresAt || null);
  res.json({ id: info.lastInsertRowid, key });
});

router.post("/:id/revoke", adminRequired, (req, res) => {
  db.prepare("UPDATE license_keys SET status = 'revoked' WHERE id = ?").run(req.params.id);
  res.json({ ok: true });
});

module.exports = router;
